/**
 * SplayTree - Splay-tree implementation
 *
 * @author  Micky Faas (s1407937)
 * @author  Lisette de Schipper (s1396250)
 * @file    SplayTree.h
 * @date    3-11-2014
 **/

#ifndef SPLAYTREE_H
#define SPLAYTREE_H

#include "SelfOrganizingTree.h"

#endif
